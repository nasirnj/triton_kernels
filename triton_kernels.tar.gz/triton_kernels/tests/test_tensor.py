# TODO: add tests for non-layout parts of tensor class
